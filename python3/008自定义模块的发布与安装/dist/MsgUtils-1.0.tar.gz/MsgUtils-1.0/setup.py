from distutils.core import setup
setup(name='MsgUtils',version='1.0',author='lieyan',description='信息发布工具包',py_modules=['packageUtil.recvMsg','packageUtil.sendMsg'])