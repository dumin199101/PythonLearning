#coding:utf-8
def test2():
    print("sendMsg----test2")